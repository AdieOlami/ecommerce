/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*------- Settings *----------*/
$('.collapsible').collapsible({
    accordion: false, // A setting that changes the collapsible behavior to expandable instead of the default accordion style
    onOpen: function(el) { alert('Open'); }, // Callback for Collapsible open
    onClose: function(el) { alert('Closed'); } // Callback for Collapsible close
});

$(document).ready(function() {
    $('input#username, textarea#textarea').characterCounter();
});

$('.datepicker').pickadate({
    selectMonths: true, // Creates a dropdown to control month
    selectYears: 100, // Creates a dropdown of 15 years to control year,
    today: 'Today',
    clear: 'Clear',
    close: 'Ok',
    closeOnSelect: false // Close upon selecting a date,
});

$(document).ready(function() {
    $('select').material_select();
    $('select').material_select('destroy');
});

/*function comment() {
    var paramstr = $("#comnt").serialize();
    $('#loading_pic').show();
    $.post("<?php echo base_url();?>comments/create",
        function(data) {
            $('#loading_pic').hide();
            if (data == "Success") {
                $('#success_msg').show();
                $('#success_msg').text(" comments posted");
            }
        });

}*/

/*$(document).ready(function() {
    $('#wrapper').css('margin', 'auto')
})*/

/*$('#submit').click(function() {
    var form_data = {
        body: $("#icon_prefix2").val()
    };
    $.ajax({
        url: "<?php echo base_url();?>comments/create",
        type: "POST",
        data: form_data,
        success: function(msg) {
            alert("msg");
        }
    });
    return true;
});*/

/*$('#submit').click(function(e) {
   e.preventDefault();
   var form_data = {
       body: $("#body").val()
   };
   $.ajax({
       url: "<?php echo base_url();?>comments/create",
       type: "POST",
       data: form_data,
       success: function(msg) {
           alert("msg");
       }
   });
   return true;
});*/

/*$('#submit').click(function(event) {
    e.preventDefault(); //stop actual action of browser
        var form_data = {
            body: $("#body").val()
        };
        $.ajax({
            url: "<?php echo base_url();?>comments/create",
            type: "POST",
            data: form_data,
            success: function(msg) {
                alert("msg");
            }
        });
        return true;
    });*/

    /*$('#submit').click(function(e) {
   e.preventDefault();
   var form_data = {
       body: $("#body").val()
   };
   $.ajax({
       url: "<?php echo base_url();?>"+"comments/create",
       type: "POST",
       data: form_data,
       success: function(msg) {
           alert("msg");
       }
   });
   return true;
});*/

  // image upload for blog post-date
