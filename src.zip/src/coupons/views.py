# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect

# Create your views here.
from django.utils import timezone
from django.views.decorators.http import require_POST
from .models import Coupon
from .forms import *


# 1. We instantiate the CouponApplyForm form using the posted data and we check that the form is valid.
# 2. Iftheformisvalid,wegetthecodeenteredbytheuserfromtheform'scleaned_datadictionary.WetrytoretrievetheCouponobjectwiththegivencode.Weusetheiexactfieldlookupto
# perform a case-insensitive exact match. The coupon has to be currently active (active=True) and valid for the current datetime. We use Django's timezone.now() function to get the current
# time-zone-aware datetime and we compare it with the valid_from and valid_to fields performing lte (less than or equal to) and gte (greater than or equal to) field lookups respectively.
# 3. Westorethecouponidintheuser'ssession.
# 4. We redirect the user to the cart_detail URL to display the cart with the coupon applied.

@require_POST
def coupon_apply(request):
    now = timezone.now()
    form = CouponApplyForm(request.POST)
    if form.is_valid():
        code = form.cleaned_data['code']
        try:
            coupon = Coupon.objects.get(code__iexact=code, valid_from__lte=now, valid_to__gte=now, active=True)
            request.session['coupon_id'] = coupon.id
        except Coupon.DoesNotExist:
            request.session['coupon_id'] = None
    return redirect('cart:cart_detail')
