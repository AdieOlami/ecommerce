from django.conf.urls import url
from . import views
from django.contrib import admin
from django.conf import settings
from django.core.urlresolvers import reverse, reverse_lazy, resolve
from django.conf.urls.static import static

app_name = 'category'

urlpatterns = [
    url(r'^$', views.index, name='index'),
    url(r'^(?P<category_slug>[-\w]+)/$', views.index, name='product_list_by_category'),
]
