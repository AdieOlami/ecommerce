from django.contrib import admin

from billing.models import *
# Register your models here.

admin.site.register(BillingProfile)
