from django import forms
from .models import Order


class OrderCreateForm(forms.ModelForm):
    class Meta(forms.ModelForm):
        model = Order
        exclude = ('shipping_total', 'order_id', 'paid', 'coupon', 'discount', 'status',)

    '''class Meta:
        model = Order
        exclude = ('shipping', 'paid', 'coupon', 'discount', 'status',)
        #fields = ['first_name', 'last_name', 'email', 'address','postal_code', 'city', 'state']
'''
