# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render, redirect

# Create your views here.
from django.core.urlresolvers import reverse
from .models import OrderItem
from .forms import OrderCreateForm
# from accounts.forms import AccountEditForm, UpdateAccount
from django.contrib.auth.models import User
# from django.contrib.auth import get_user_model
from django.contrib.auth.decorators import login_required
from cart.cart import *
from .tasks import order_created
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import get_object_or_404
from .models import Order
# from accounts.models import Account
# from shipping.forms import AbstractAddressForm
# from shipping.forms import UserAddressForm
# from shipping.models import AbstractUserAddress
from django.conf import settings
from django.http import HttpResponse
from django.template.loader import render_to_string
import weasyprint

# from weasyprint import HTML, CSS
# from weasyprint.fonts import FontConfiguration


'''
def order_create(request):
    #obtain the current cart from the session with cart = Cart(request)
    cart = Cart(request)
    user = request.user
    #account = Account.objects.filter(user)
    if user.is_authenticated():
        # we create an Order object using the save() method of the OrderCreateForm form. We avoid saving it to the database yet by using commit=False. If the cart contains a coupon,
        #we store the related coupon and the discount that was applied. Then we save the order object to the database
        order = user.save(commit=False)
        if cart.coupon:
            order.coupon = cart.coupon
            order.discount = cart.coupon.discount
        order.save()
        for item in cart:
            OrderItem.objects.create(
                order=order,
                product=item['product'],
                price=item['price'],
                quantity=item['quantity']
            )
        # clear the cart
        cart.clear()
        # launch asynchronous task
        order_created.delay(order.id) # set the order in the session
        #we set the order ID in the current session using the order_id session key
        request.session['order_id'] = order.id
        # redirect to the payment
        return redirect(reverse('payment:process'))
        context = {
            'order': order,
            'account': account,
            }
        template = 'order/created.html'
        return render(request,template,context)
    else:
        messages.error(request, "Kindly confirm your email")
    context = {
        'cart': cart,
        }
    template = 'order/create.html'
    return render(request,template,context)
'''


# Create your views here.
@login_required
def account(request):
    user = request.user
    context = {
        'user': user
    }
    template = 'account.html'
    return render(request, template, context)


def load_account(user):
    try:
        return user.account
    except:  # this is not great, but trying to keep it simple
        account = Account.objects.create(user=user)
        return account


'''

def order_create(request):
    cart = Cart(request)
    order = Order.objects.filter(user=request.user)
    # order = load_account(request.user)
    if account.is_authenticated:
        # order = account.save()
        for item in cart:
            OrderItem.objects.create(
                order=order,
                product=item['product'],
                price=item['price'],
                quantity=item['quantity']
            )
        cart.clear()
        # launch asynchronous task
        order_created.delay(order.id)  # set the order in the session
        # we set the order ID in the current session using the order_id session key
        request.session['order_id'] = order.id
        # redirect to the payment
        return redirect(reverse('payment:process'))
        context = {
            'order': order,
        }
        template = 'order/created.html'
        return render(request, template, context)
    else:
        return redirect('account:update_account')
    context = {
        'cart': cart,
        'form': form,
    }
    template = 'order/create.html'
    return render(request, template, context)


'''

'''
.objects.filter(user=request.user)
'''

'''
def order_create(request):
    cart = Cart(request)
    # account = load_account(request.user)
    user = request.user
    billing_profile = None
    if user.is_authenticated():
        billing_profile = None
    if request.method == 'POST':
        form = OrderCreateForm(request.POST)
        # form = AbstractAddressForm(user=request.user, instance=request.POST)
        # form = AbstractUserAddress.objects.filter(user=request.user)
        if form.is_valid():
            order = form.save()
            for item in cart:
                OrderItem.objects.create(
                    order=order,
                    product=item['product'],
                    price=item['price'],
                    quantity=item['quantity']
                )  # .filter(user=request.user)
            cart.clear()
            # launch asynchronous task
            # order_created.delay(order.id)  # set the order in the session
            # we set the order ID in the current session using the order_id session key
            # request.session['order_id'] = order.id
            # redirect to the payment
            # return redirect(reverse('payment:process'))
            context = {
                'order': order,
                'billing_profile': billing_profile,
            }
            template = 'order/created.html'
            return render(request, template, context)
    else:
        # form = UserAddressForm(user=request.user)
        form = OrderCreateForm()
    context = {
        'cart': cart,
        'billing_profile': billing_profile,
    }
    template = 'order/create.html'
    return render(request, template, context)
'''


def order_create(request):
    cart = Cart(request)
    # account = load_account(request.user)
    user = request.user
    # order = Order.objects.filter(status=1)
    billing_profile = None
    if user.is_authenticated():
        billing_profile = None
        for item in cart:
            OrderItem.objects.create(
                product=item['product'],
                price=item['price'],
                quantity=item['quantity']
            )  # .filter(user=request.user)
        cart.clear()
        # launch asynchronous task
        # order_created.delay(order.id)  # set the order in the session
        # we set the order ID in the current session using the order_id session key
        # request.session['order_id'] = order.id
        # redirect to the payment
        # return redirect(reverse('payment:process'))
        context = {
            # 'order': order,
            'billing_profile': billing_profile,
        }
        template = 'order/created.html'
        return render(request, template, context)
    else:
        # form = UserAddressForm(user=request.user)
        print("None")
    context = {
        'cart': cart,
        'billing_profile': billing_profile,
    }
    template = 'order/create.html'
    return render(request, template, context)


def checkout_home(request):
    cart_obj, new_obj = Cart(request)
    order_obj, new_order_obj = OrderItem.objects.filter(order=cart_obj)
    return render(request, "", {"objects": order_obj})


'''

class ShippingAddressView(generic.FormView):
    """
    Determine the shipping address for the order.

    The default behaviour is to display a list of addresses from the users's
    address book, from which the user can choose one to be their shipping
    address.  They can add/edit/delete these USER addresses.  This address will
    be automatically converted into a SHIPPING address when the user checks
    out.

    Alternatively, the user can enter a SHIPPING address directly which will be
    saved in the session and later saved as ShippingAddress model when the
    order is successfully submitted.
    """
    template_name = 'checkout/shipping_address.html'
    form_class = ShippingAddressForm
    success_url = reverse_lazy('checkout:shipping-method')
    pre_conditions = ['check_basket_is_not_empty',
                      'check_basket_is_valid',
                      'check_user_email_is_captured']
    skip_conditions = ['skip_unless_basket_requires_shipping']
    cart = Cart(request)

    def get_initial(self):
        request.session['order_id'] = order.id
        initial = self.checkout_session.new_shipping_address_fields()
        if initial:
            initial = initial.copy()
            # Convert the primary key stored in the session into a Country
            # instance
            try:
                initial['country'] = Country.objects.get(
                    iso_3166_1_a2=initial.pop('country_id'))
            except Country.DoesNotExist:
                # Hmm, the previously selected Country no longer exists. We
                # ignore this.
                pass
        return initial

    def get_context_data(self, **kwargs):
        ctx = super(ShippingAddressView, self).get_context_data(**kwargs)
        if user_is_authenticated(self.request.user):
            # Look up address book data
            ctx['addresses'] = self.get_available_addresses()
        return ctx

    def get_available_addresses(self):
        # Include only addresses where the country is flagged as valid for
        # shipping. Also, use ordering to ensure the default address comes
        # first.
        return self.request.user.addresses.filter(
            country__is_shipping_country=True).order_by(
            '-is_default_for_shipping')

    def post(self, request, *args, **kwargs):
        # Check if a shipping address was selected directly (eg no form was
        # filled in)
        if user_is_authenticated(self.request.user) \
                and 'address_id' in self.request.POST:
            address = UserAddress._default_manager.get(
                pk=self.request.POST['address_id'], user=self.request.user)
            action = self.request.POST.get('action', None)
            if action == 'ship_to':
                # User has selected a previous address to ship to
                self.checkout_session.ship_to_user_address(address)
                return redirect(self.get_success_url())
            else:
                return http.HttpResponseBadRequest()
        else:
            return super(ShippingAddressView, self).post(
                request, *args, **kwargs)

    def form_valid(self, form):
        # Store the address details in the session and redirect to next step
        address_fields = dict(
            (k, v) for (k, v) in form.instance.__dict__.items()
            if not k.startswith('_'))
        self.checkout_session.ship_to_new_address(address_fields)
        return super(ShippingAddressView, self).form_valid(form)
    
    



'''


@staff_member_required
def admin_order_detail(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    context = {
        'order': order,
    }
    template = 'order/detail.html'
    return render(request, template, context)


# For PDF
@staff_member_required
def admin_order_pdf(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    html = render_to_string(
        'order/pdf.html',
        {'order': order}
    )
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'filename=\ "order_{}.pdf"'.format(order.id)
    weasyprint.HTML(string=html).write_pdf(response, stylesheets=[weasyprint.CSS(settings.STATIC_ROOT + 'css/pdf.css')])
    return response
