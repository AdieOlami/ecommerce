# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
from product.models import *
# from shipping.models import Shipping
from django.contrib.auth.models import User
from django.db.models.signals import pre_save
from decimal import Decimal
from django.core.validators import MinValueValidator, MaxValueValidator
from django.utils.translation import ugettext_lazy as _
from coupons.models import *
from billing.models import *
from softraders.utils import *
from cart.cart import *
# from accounts.models import Account
from django.conf import settings
from django.db.models.signals import pre_save
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType


# from shipping.models import AbstractAddress
# from shipping.abstract_models import (AbstractUserAddress)





class Order(models.Model):
    SUBMITTED = 1
    PROCESSED = 2
    SHIPPED = 3
    CANCELLED = 4

    # user = models.ForeignKey(User, related_name='user_account')
    # cart = ForeignKey(Cart, related_name='user_account')
    order_id = models.CharField(max_length=120)
    # billing = models.ForeignKey(BillingProfile)
    # .shipping = models.ForeignKey(Shipping, related_name='shipping_items', blank=True, null=True)
    # user = models.OneToOneField(settings.AUTH_USER_MODEL, related_name='user_account')
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    paid = models.BooleanField(default=False)
    coupon = models.ForeignKey(Coupon, related_name='orders', null=True, blank=True)
    # shipping_total = models.DecimalField(max_digits=100, decimal_places=2)
    discount = models.IntegerField(default=0, validators=[MinValueValidator(0), MaxValueValidator(100)])
    # set of possible order statuses
    ORDER_STATUS = (
        (SUBMITTED, 'Submitted'), (PROCESSED, 'Processed'), (SHIPPED, 'Shipped'), (CANCELLED, 'Cancelled'),)
    # order info
    status = models.IntegerField(choices=ORDER_STATUS, default=SUBMITTED)

    class Meta:
        ordering = ('-created',)

    def __str__(self):
        return 'Order {}'.format(self.id)

    def get_total_cost(self):
        total_cost = sum(item.get_cost() for item in self.items.all())
        return total_cost - total_cost * (self.discount / Decimal('100'))


def pre_save_create_order_id(sender, instance, *args, **kwargs):
    if not instance.order_id:
        instance.order_id = unique_order_id_generator(instance)

pre_save.connect(pre_save_create_order_id, sender=Order)


class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name='items', blank=True, null=True)
    product = models.ForeignKey(Product, related_name='order_items')
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return '{}'.format(self.id)

    def get_cost(self):
        return self.price * self.quantity
