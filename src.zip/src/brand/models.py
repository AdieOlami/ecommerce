# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
from django.core.urlresolvers import reverse, reverse_lazy, resolve
from django.conf import settings
from django.db.models.signals import pre_save
from django.utils import timezone
#from product.models import Product
from django.utils.text import slugify
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType


class Brand(models.Model):
    name = models.CharField(max_length=400,db_index=True)
    slug = models.SlugField(max_length=400,db_index=True, unique=True)

    class Meta:
        ordering = ('name',)
        verbose_name = 'brand'
        verbose_name_plural = 'brands'

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('brand:product_list_by_brand', args=[self.slug])