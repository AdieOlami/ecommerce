# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, get_object_or_404
from .models import Brand
from product.models import *


def index(request, brand_slug=None):
    brand = None
    brands = Brand.objects.all()
    products = Product.objects.filter(available=True)
    if brand_slug:
        brand = get_object_or_404(Brand, slug=brand_slug)
        products = products.filter(brand=brand)

    context = {
        'brand': brand,
        'brands': brands,
        'products': products
    }
    template = 'brand/index.html'
    return render(request, template, context)
