from django.conf.urls import url
from . import views
from django.contrib import admin
from django.conf import settings
from django.core.urlresolvers import reverse, reverse_lazy, resolve
from django.conf.urls.static import static

app_name = 'product'

urlpatterns = [
    # url(r'^$', views.product_list, name='product_list'),
    # url(r'^(?P<category_slug>[-\w]+)/$',views.product_list,name='product_list_by_category'),
    # url(r'^(?P<id>\d+)/(?P<slug>[-\w]+)/$', views.detail, name='detail'),
    url(r'^(?P<slug>[-\w]+)/$', views.detail, name='detail'),

]
